import { font } from "./font.js";
import { menu } from "./menu.js";
import fs from "node:fs";
import sharp from "sharp";
import {
  downloadContentFromMessage
} from "@whiskeysockets/baileys";

const DATA_FILE = "data/bot-data.json";

function loadData() {
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
  } catch {
    return { mutedUsers: [], activity: {} };
  }
}

const data = loadData();
export const mutedUsers = new Set(data.mutedUsers || []);
const activity = data.activity || {};
const recentImages = new Map();

function saveData() {
  fs.mkdirSync("data", { recursive: true });
  fs.writeFileSync(DATA_FILE, JSON.stringify({
    mutedUsers: [...mutedUsers],
    activity
  }, null, 2));
}

function normalize(jid) {
  return jid ? jid.replace(/:\d+(?=@)/, "") : "";
}

function getContext(msg) {
  return msg.message?.extendedTextMessage?.contextInfo || {};
}

function getTarget(msg) {
  const context = getContext(msg);
  return context.mentionedJid?.[0] || context.participant || null;
}

function getText(msg) {
  const m = msg.message || {};
  return m.conversation ||
    m.extendedTextMessage?.text ||
    m.imageMessage?.caption ||
    m.videoMessage?.caption ||
    m.documentMessage?.caption || "";
}

function isAdmin(participant) {
  return participant?.admin === "admin" ||
    participant?.admin === "superadmin";
}

async function groupInfo(sock, jid) {
  const metadata = await sock.groupMetadata(jid);

  const botIds = [
    sock.user?.id,
    sock.user?.lid
  ].filter(Boolean).map(normalize);

  const bot = metadata.participants.find(p =>
    [p.id, p.lid].filter(Boolean).some(id =>
      botIds.includes(normalize(id))
    )
  );

  if (!isAdmin(bot)) {
    console.log("DIAGNÓSTICO DE ADMINISTRADOR:", {
      botIdentificado: Boolean(bot),
      botEsAdmin: isAdmin(bot),
      participantes: metadata.participants.length
    });

    throw new Error("El bot debe ser administrador de este grupo.");
  }

  return metadata;
}

async function issuerIsAdmin(sock, jid, msg, metadata) {
  const sender = msg.key.participant || msg.key.remoteJid;
  const participant = metadata.participants.find(
    p => normalize(p.id) === normalize(sender)
  );
  return isAdmin(participant) || msg.key.fromMe;
}

async function downloadImage(imageMessage) {
  const stream = await downloadContentFromMessage(imageMessage, "image");
  const chunks = [];
  for await (const chunk of stream) chunks.push(chunk);
  return Buffer.concat(chunks);
}

export async function rememberImage(msg, sock) {
  const image = msg.message?.imageMessage;
  const jid = msg.key.remoteJid;
  const sender = msg.key.participant;

  if (!image || !jid?.endsWith("@g.us") || !sender) return;

  try {
    const buffer = await downloadImage(image);
    recentImages.set(`${jid}:${sender}`, buffer);
  } catch (error) {
    console.error("No se pudo guardar imagen reciente:", error.message);
  }
}

function escapeXml(text) {
  return String(text).replace(/[&<>"']/g, c => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&apos;"
  })[c]);
}

function wrapText(text, max = 17) {
  const words = text.trim().split(/\s+/);
  const lines = [];
  let line = "";

  for (const word of words) {
    if ((line + " " + word).trim().length > max && line) {
      lines.push(line);
      line = word;
    } else {
      line = (line + " " + word).trim();
    }
  }

  if (line) lines.push(line);
  return lines.slice(0, 7);
}


async function qcSticker(text, name, avatar) {
  const lines = wrapText(text, 25);
  const safeName = escapeXml(name || "Usuario");
  const h = Math.min(420, 150 + lines.length * 38);
  const y = Math.round((512 - h) / 2);
  const message = lines.map((line, i) =>
    `<text x="256" y="${y + 112 + i * 36}" text-anchor="middle" font-family="Arial" font-size="27" fill="#FFFFFF">${escapeXml(line)}</text>`
  ).join("");
  const svg = `<svg width="512" height="512" xmlns="http://www.w3.org/2000/svg">
    <path d="M55 ${y} H457 Q487 ${y} 487 ${y+30} V${y+h-35} Q487 ${y+h-5} 457 ${y+h-5} H85 L48 ${y+h+15} L58 ${y+h-5} Q25 ${y+h-5} 25 ${y+h-35} V${y+30} Q25 ${y} 55 ${y}Z" fill="#000000"/>
    <circle cx="82" cy="${y+53}" r="32" fill="#59636B"/>
    <text x="82" y="${y+64}" text-anchor="middle" font-family="Arial" font-size="27" fill="white">${escapeXml((name || "U").slice(0,1).toUpperCase())}</text>
    <text x="128" y="${y+61}" font-family="Arial" font-size="23" font-weight="bold" fill="white">${safeName.slice(0,30)}</text>
    ${message}
  </svg>`;
  let base = sharp(Buffer.from(svg));
  if (avatar) {
    try {
      const mask = Buffer.from('<svg width="64" height="64"><circle cx="32" cy="32" r="32" fill="white"/></svg>');
      const pic = await sharp(avatar).resize(64,64).composite([{input:mask,blend:"dest-in"}]).png().toBuffer();
      base = base.composite([{input:pic,left:50,top:y+21}]);
    } catch {}
  }
  return base.webp().toBuffer();
}

async function textSticker(text, style) {
  const lines = wrapText(text);
  const color = style === "brat" ? "#8ACF00" : "#FFFFFF";
  const textColor = "#000000";
  const fontSize = lines.length > 4 ? 38 : 48;
  const startY = 256 - ((lines.length - 1) * fontSize * 0.55);

  const textSvg = lines.map((line, i) =>
    `<text x="256" y="${startY + i * fontSize * 1.1}" text-anchor="middle" font-family="Arial, sans-serif" font-size="${fontSize}" font-weight="bold" fill="${textColor}">${escapeXml(line)}</text>`
  ).join("");

  const svg = `<svg width="512" height="512" xmlns="http://www.w3.org/2000/svg"><rect width="512" height="512" rx="24" fill="${color}"/>${style === "qc" ? '<rect x="20" y="20" width="472" height="472" rx="28" fill="none" stroke="black" stroke-width="8"/>' : ""}${textSvg}</svg>`;

  return sharp(Buffer.from(svg)).webp().toBuffer();
}


function loadAdminModes() {
  try {
    return JSON.parse(fs.readFileSync("data/modoadmin.json", "utf8"));
  } catch {
    return {};
  }
}

function saveAdminModes(data) {
  fs.mkdirSync("data", { recursive: true });
  fs.writeFileSync("data/modoadmin.json", JSON.stringify(data, null, 2));
}


const triviaGames = new Map();
const triviaPoints = new Map();
const tttGames = new Map();

export async function handleCommand(command, sock, msg, args = []) {
  const jid = msg.key.remoteJid;

  if (!jid?.endsWith("@g.us")) {
    return "Este comando solo funciona en grupos.";
  }

  let metadata;

  try {
    metadata = await groupInfo(sock, jid);
  } catch (error) {
    return error.message;
  }

  const participants = metadata.participants;

const adminModes = loadAdminModes();
if (adminModes[jid] && command !== "modoadmin" &&
    !(await issuerIsAdmin(sock, jid, msg, metadata))) {
  return font("Este bot esta en modo administrador. Solo los administradores pueden usar sus comandos.");
}

  const ids = participants.map(p => p.id).filter(Boolean);
  const target = getTarget(msg);
  const sender = msg.key.participant || msg.key.remoteJid;
  const admin = await issuerIsAdmin(sock, jid, msg, metadata);

  if (["kick", "promote", "demote", "mute", "unmute", "gon", "goff"].includes(command) && !admin) {
    return "Solo los administradores del grupo pueden usar este comando.";
  }

  try {
    switch (command) {
      case "menu": {
await sock.sendMessage(msg.key.remoteJid, {
image: fs.readFileSync("media/menu.jpeg"),
caption: menu
}, { quoted: msg });
return null;
}

      case "kick":
        if (!target) return "Uso: .kick @usuario o responde a su mensaje.";
        await sock.groupParticipantsUpdate(jid, [target], "remove");
        return "Usuario expulsado.";

      case "promote":
      case "demote":
        if (!target) return `Uso: .${command} @usuario o responde a su mensaje.`;
        await sock.groupParticipantsUpdate(
          jid,
          [target],
          command === "promote" ? "promote" : "demote"
        );
        return command === "promote" ? "Administrador concedido." : "Administrador retirado.";

      case "todos": {
  const text =
    `${font("Invocados por Juniorstiven ✌🏽!")}\n\n` +
    `${font("Etiquetas:")}\n\n` +
    ids.map(id => `👻 @${id.split("@")[0]}`).join("\n");

  await sock.sendMessage(jid, {
    text,
    mentions: ids
  }, { quoted: msg });

  return null;
}


case "n": {
const ids = participants.map(p => p.id).filter(Boolean);
if (!ids.length) return font("No hay integrantes para mencionar.");

const aviso = args.join(" ").trim();
const metadataGrupo = await sock.groupMetadata(jid);
const nombreGrupo = metadataGrupo.subject || "Grupo";

await sock.sendMessage(jid, {
text: `${aviso || font("Atención a todos.")}\n\n> ${nombreGrupo}`,
mentions: ids
}, { quoted: msg });

return null;
}

case "ship": {
    const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    const pair = [...new Set(mentioned)].slice(0, 2);
    const pool = participants.map(p => p.id).filter(id =>
        id && !pair.includes(id) && id !== sock.user?.id
    );

    while (pair.length < 2 && pool.length) {
        const index = Math.floor(Math.random() * pool.length);
        pair.push(pool.splice(index, 1)[0]);
    }

    if (pair.length < 2)
        return font("Se necesitan dos integrantes para jugar.");

    const percent = Math.floor(Math.random() * 101);
    const names = pair.map(id => "@" + id.split("@")[0]);

    await sock.sendMessage(jid, {
        text: `${font("COMPATIBILIDAD")}

${names[0]} ❤️ ${names[1]}

${font("Resultado: " + percent + "%")}`,
        mentions: pair
    }, { quoted: msg });
    return null;
}

case "dado": {
    const number = Math.floor(Math.random() * 6) + 1;
    return font("🎲 DADO: " + number);
}

case "ppt": {
    const choices = ["piedra", "papel", "tijera"];
    const userChoice = args.join(" ").trim().toLowerCase();

    if (!choices.includes(userChoice))
        return font("Uso: .ppt piedra, .ppt papel o .ppt tijera");

    const botChoice = choices[Math.floor(Math.random() * choices.length)];
    let result = "EMPATE";
    let emoji = "🤝";

    if (
        (userChoice === "piedra" && botChoice === "tijera") ||
        (userChoice === "papel" && botChoice === "piedra") ||
        (userChoice === "tijera" && botChoice === "papel")
    ) {
        result = "GANASTE";
        emoji = "🏆";
    } else if (userChoice !== botChoice) {
        result = "PERDISTE";
        emoji = "❌";
    }

    const message = [
        font("✊ PIEDRA, PAPEL O TIJERA"),
        "",
        "━━━━━━━━━━━━━━━━",
        "",
        "👤 " + font("Tu: ") + font(userChoice),
        "🤖 " + font("Bot: ") + font(botChoice),
        "",
        "━━━━━━━━━━━━━━━━",
        "",
        emoji + " " + font(result),
        "",
        font("JUNIORSTIVEN BOT")
    ].join("\n");

    return message;
}


case "trivia": {
    const sender = msg.key.participant || msg.key.remoteJid;
    const key = jid + ":" + sender;
    const questions = [
        ["¿Cuál es la capital de Colombia?", "bogota", "Bogotá"],
        ["¿Cuántos lados tiene un hexágono?", "6", "Seis"],
        ["¿Cuál es el planeta rojo?", "marte", "Marte"],
        ["¿Quién escribió Don Quijote?", "miguel de cervantes", "Miguel de Cervantes"],
        ["¿Cuánto es 9 x 8?", "72", "72"],
        ["¿Cuál es el océano más grande?", "pacifico", "Pacífico"],
        ["¿Cuántos continentes hay?", "7", "Siete"],
        ["¿Qué gas necesitan las plantas para la fotosíntesis?", "dioxido de carbono", "Dióxido de carbono"],
        ["¿Cuál es el animal terrestre más grande?", "elefante", "Elefante"],
        ["¿En qué continente está Egipto?", "africa", "África"]
    ];
    if (args.length) {
        const game = triviaGames.get(key);
        if (!game) return font("No tienes una pregunta activa. Escribe .trivia");
        const answer = args.join(" ").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
        const correct = game.answer.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
        triviaGames.delete(key);
        if (answer === correct) {
            const points = (triviaPoints.get(sender) || 0) + 1;
            triviaPoints.set(sender, points);
            return font("¡CORRECTO! +1 punto\nPuntos acumulados: " + points);
        }
        return font("Respuesta incorrecta.\nRespuesta correcta: " + game.display);
    }
    const q = questions[Math.floor(Math.random() * questions.length)];
    triviaGames.set(key, { answer: q[1], display: q[2] });
    return font("TRIVIA\n\n" + q[0] + "\n\nResponde con:\n.trivia tu respuesta");
}

case "tictactoe": {
    const sender = msg.key.participant || msg.key.remoteJid;
    const target = getTarget(msg);
    let game = tttGames.get(jid);

    if (target) {
        if (target === sender) return font("No puedes jugar contra ti mismo.");
        if (game) return font("Ya hay una partida activa en este grupo.");
        game = { players: [sender, target], board: Array(9).fill(" "), turn: 0 };
        tttGames.set(jid, game);
        await sock.sendMessage(jid, {
            text: font("TRES EN RAYA\n\n@" + sender.split("@")[0] + " (X) contra @" + target.split("@")[0] + " (O)\n\n" +
                "1️⃣ 2️⃣ 3️⃣\n4️⃣ 5️⃣ 6️⃣\n7️⃣ 8️⃣ 9️⃣\n\nEmpieza el jugador X.\nUsa .tictactoe 1-9"),
            mentions: [sender, target]
        }, { quoted: msg });
        return null;
    }

    if (!game) return font("Para iniciar: .tictactoe @usuario");
    if (game.players[game.turn] !== sender) return font("No es tu turno.");
    const position = Number(args[0]) - 1;
    if (!Number.isInteger(position) || position < 0 || position > 8)
        return font("Elige una casilla del 1 al 9. Ejemplo: .tictactoe 5");
    if (game.board[position] !== " ") return font("Esa casilla ya está ocupada.");

    game.board[position] = game.turn === 0 ? "X" : "O";
    const b = game.board;
    const wins = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
    const lines = b.map((v, i) => v === " " ? String(i + 1) : v);
    const boardText = lines.slice(0,3).join(" | ") + "\n" +
        lines.slice(3,6).join(" | ") + "\n" + lines.slice(6,9).join(" | ");
    const winner = wins.some(line => line.every(i => b[i] === b[line[0]] && b[i] !== " "));
    if (winner || b.every(v => v !== " ")) {
        tttGames.delete(jid);
        return font("TRES EN RAYA\n\n" + boardText + "\n\n" +
            (winner ? "¡GANÓ " + (game.turn === 0 ? "X" : "O") + "!" : "¡EMPATE!") +
            "\n\nPartida finalizada.");
    }
    game.turn = 1 - game.turn;
    await sock.sendMessage(jid, {
        text: font("TRES EN RAYA\n\n" + boardText + "\n\nTurno de " +
            (game.turn === 0 ? "X" : "O") + ": @" + game.players[game.turn].split("@")[0] +
            "\nUsa .tictactoe 1-9"),
        mentions: [game.players[game.turn]]
    }, { quoted: msg });
    return null;
}

case "owner":

  return font("👑 Propietario: JUNIORSTIVEN");

case "admins": {
        const admins = participants.filter(isAdmin).map(p => p.id);
        if (!admins.length) return "No se encontraron administradores.";
        await sock.sendMessage(jid, {
          text: `👑 𝗔𝗗𝗠𝗜𝗡𝗜𝗦𝗧𝗥𝗔𝗗𝗢𝗥𝗘𝗦\n\n${admins.map(id => `@${id.split("@")[0]}`).join("\n")}`,
          mentions: admins
        }, { quoted: msg });
        return null;
      }

      case "mute":
      case "unmute": {
        if (!target) return `Uso: .${command} @usuario o responde a su mensaje.`;
        const key = `${jid}:${target}`;

        if (command === "mute") {
          mutedUsers.add(key);
          saveData();
          return "Usuario silenciado. Sus próximos mensajes serán eliminados.";
        }

        mutedUsers.delete(key);
        saveData();
        return "Usuario desilenciado.";
      }

      case "mutelist": {
        const list = [...mutedUsers]
          .filter(key => key.startsWith(`${jid}:`))
          .map(key => key.slice(jid.length + 1));

        if (!list.length) return "No hay usuarios silenciados.";
        await sock.sendMessage(jid, {
          text: `🔇 USUARIOS SILENCIADOS\n\n${list.map(id => `@${id.split("@")[0]}`).join("\n")}`,
          mentions: list
        }, { quoted: msg });
        return null;
      }

      case "gon":
      case "goff":
        await sock.groupSettingUpdate(
          jid,
          command === "gon" ? "not_announcement" : "announcement"
        );
        return command === "gon" ? "Grupo abierto. Todos pueden enviar mensajes." : "Grupo cerrado. Solo administradores pueden enviar mensajes.";

      case "link": {
  const code = await sock.groupInviteCode(jid);

  if (!code) {
    return "No se pudo obtener el enlace del grupo.";
  }

  return `${font("Enlace del grupo:")}\nhttps://chat.whatsapp.com/${code}`;
}

case "fantasmas": {
        const now = Date.now();
        const limit = 72 * 60 * 60 * 1000;

        const ghosts = participants
          .filter(p => {
            const last = activity[`${jid}:${p.id}`];
            return last && now - last >= limit && !isAdmin(p);
          })
          .map(p => p.id);

        if (!ghosts.length) {
          return "No hay participantes con 3 días de inactividad comprobada. El registro empieza desde que se activa esta función.";
        }

        await sock.sendMessage(jid, {
          text: `👻 INACTIVOS POR 3 DÍAS O MÁS\n\n${ghosts.map(id => `@${id.split("@")[0]}`).join("\n")}`,
          mentions: ghosts
        }, { quoted: msg });
        return null;
      }

      
// JUNIORSTIVEN_STICKERS_V2
case "toimg": {
    const quoted = getContext(msg).quotedMessage;
    if (!quoted?.stickerMessage)
        return font("Responde a un sticker con .toimg");

    const stream = await downloadContentFromMessage(
        quoted.stickerMessage, "sticker"
    );
    const chunks = [];
    for await (const chunk of stream) chunks.push(chunk);

    const image = await sharp(Buffer.concat(chunks)).png().toBuffer();
    await sock.sendMessage(jid, { image }, { quoted: msg });
    return null;
}

case "ttp": {
    const text = args.join(" ").trim();
    if (!text) return font(`Uso: .${command} escribe tu texto`);

    const sticker = await textSticker(text, command);
    await sock.sendMessage(jid, { sticker }, { quoted: msg });
    return null;
}

case "smeme": {
    const quoted = getContext(msg).quotedMessage;
    if (!quoted?.imageMessage)
        return font("Responde a una imagen con .smeme TEXTO ARRIBA | TEXTO ABAJO");

    const buffer = await downloadImage(quoted.imageMessage);
    if (!buffer) return font("No se pudo descargar la imagen.");

    const parts = args.join(" ").split("|");
    const escape = t => t.replace(/&/g, "&amp;")
        .replace(/</g, "&lt;").replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");

    const top = escape((parts[0] || "").trim());
    const bottom = escape((parts[1] || "").trim());

    const svg = Buffer.from(`
    <svg width="512" height="512" xmlns="http://www.w3.org/2000/svg">
      <style>
        text { font-family: Impact, Arial, sans-serif;
        font-size: 32px; font-weight: bold; fill: white;
        stroke: black; stroke-width: 2px; paint-order: stroke;
        text-anchor: middle; }
      </style>
      <text x="256" y="45">${top}</text>
      <text x="256" y="485">${bottom}</text>
    </svg>`);

    const sticker = await sharp(buffer)
        .resize(512, 512, { fit: "contain",
            background: { r: 0, g: 0, b: 0, alpha: 0 } })
        .composite([{ input: svg }])
        .webp()
        .toBuffer();

    await sock.sendMessage(jid, { sticker }, { quoted: msg });
    return null;
}
// FIN JUNIORSTIVEN_STICKERS_V2


case "s": {
        const context = getContext(msg);
        let buffer = null;

        if (context.quotedMessage?.imageMessage) {
          buffer = await downloadImage(context.quotedMessage.imageMessage);
        } else if (target) {
          buffer = recentImages.get(`${jid}:${target}`);
        }

        if (!buffer) return "Responde a una imagen o menciona a alguien cuya imagen reciente haya sido recibida por el bot.";

        const sticker = await sharp(buffer)
          .resize(512, 512, { fit: "contain", background: { r: 0, g: 0, b: 0, alpha: 0 } })
          .webp()
          .toBuffer();

        await sock.sendMessage(jid, { sticker }, { quoted: msg });
        return null;
      }

      case "qc": {
  const text = args.join(" ").trim();
  if (!text) return "Uso: .qc escribe tu texto";
  const sender = msg.key.participant || jid;
  const name = msg.pushName || "Usuario";
  let avatar = null;
  try {
    const url = await sock.profilePictureUrl(sender, "image");
    const response = await fetch(url);
    if (response.ok) avatar = Buffer.from(await response.arrayBuffer());
  } catch {}
  const sticker = await qcSticker(text, name, avatar);
  await sock.sendMessage(jid, { sticker }, { quoted: msg });
  return null;
}


      case "modoadmin": {
        if (!(await issuerIsAdmin(sock, jid, msg, metadata)))
          return font("Solo los administradores pueden cambiar este modo.");
        const option = (args[0] || "").toLowerCase();
        if (option !== "on" && option !== "off")
          return font("Uso: .modoadmin on / .modoadmin off");
        const modes = loadAdminModes();
        if (option === "on") modes[jid] = true;
        else delete modes[jid];
        saveAdminModes(modes);
        return font(option === "on" ? "Modo administrador activado." : "Modo administrador desactivado.");
      }
      default:
        return null;
    }
  } catch (error) {
    console.error(`Error en comando ${command}:`, error);
    return `No se pudo ejecutar el comando: ${error.message}`;
  }
}

export function recordActivity(msg) {
  const jid = msg.key.remoteJid;
  const sender = msg.key.participant;

  if (!jid?.endsWith("@g.us") || !sender || msg.key.fromMe) return;

  activity[`${jid}:${sender}`] = Date.now();
  saveData();
}

export function shouldDeleteMuted(msg) {
  const jid = msg.key.remoteJid;
  const sender = msg.key.participant;
  if (!jid?.endsWith("@g.us") || !sender) return false;
  return mutedUsers.has(`${jid}:${sender}`);
}
