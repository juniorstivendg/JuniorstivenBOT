import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  normalizeMessageContent
} from "@whiskeysockets/baileys";

import pino from "pino";
import { font } from "./font.js";

import {
  handleCommand,
  recordActivity,
  rememberImage,
  shouldDeleteMuted
} from "./commands.js";

let reconnectTimer = null;
let starting = false;
let stopped = false;

async function startBot() {
  if (starting || stopped) return;

  starting = true;

  try {
    console.log("Iniciando JUNIORSTIVEN BOT...");

    const { state, saveCreds } =
      await useMultiFileAuthState("auth_info");

    const sock = makeWASocket({
      auth: state,
      logger: pino({ level: "silent" }),
      printQRInTerminal: false,
      browser: ["JUNIORSTIVEN BOT", "Chrome", "1.0.0"],
      syncFullHistory: false,
      markOnlineOnConnect: true,
      connectTimeoutMs: 60000,
      defaultQueryTimeoutMs: 60000
    });

    sock.ev.on("creds.update", saveCreds);

    sock.ev.on("connection.update", ({ connection, lastDisconnect }) => {
      if (connection === "connecting") {
        console.log("Conectando con WhatsApp...");
      }

      if (connection === "open") {
        starting = false;
        console.log("JUNIORSTIVEN BOT CONECTADO.");
        console.log("Esperando mensajes y comandos...");
      }

      if (connection === "close") {
        starting = false;

        const status = lastDisconnect?.error?.output?.statusCode;

        console.log("CONEXIÓN CERRADA. Código:", status);

        if (status === DisconnectReason.loggedOut) {
          stopped = true;
          console.log("La sesión fue cerrada por WhatsApp.");
          return;
        }

        if (!reconnectTimer && !stopped) {
          reconnectTimer = setTimeout(() => {
            reconnectTimer = null;
            startBot();
          }, 5000);
        }
      }
    });

    sock.ev.on("messages.upsert", async ({ messages, type }) => {
      if (type !== "notify") return;

      for (const msg of messages) {
        try {
          if (!msg.message) continue;

          const content =
            normalizeMessageContent(msg.message) || msg.message;

          const text =
            content.conversation ||
            content.extendedTextMessage?.text ||
            content.imageMessage?.caption ||
            content.videoMessage?.caption ||
            content.documentMessage?.caption ||
            "";

          const jid = msg.key.remoteJid;

          if (!jid?.endsWith("@g.us")) continue;

          recordActivity(msg);
          await rememberImage(msg, sock);

          const cleanText = text.trim();

          if (
            shouldDeleteMuted(msg) &&
            !/^\.unmute(?:\s|$)/i.test(cleanText)
          ) {
            try {
              await sock.sendMessage(jid, {
                delete: msg.key
              });
            } catch (error) {
              console.error("ERROR ELIMINANDO MENSAJE:", error);
            }

            continue;
          }

          if (!cleanText.startsWith(".")) continue;

          const parts = cleanText.slice(1).trim().split(/\s+/);
          const command = parts.shift()?.toLowerCase();

          if (!command) continue;

          console.log("COMANDO DETECTADO:", command);

          const response = await handleCommand(
            command,
            sock,
            msg,
            parts
          );

          if (response) {
            await sock.sendMessage(
              jid,
              { text: command === "link" ? response : font(response) },
              { quoted: msg }
            );

            console.log("RESPUESTA ENVIADA:", command);
          }
        } catch (error) {
          console.error("ERROR PROCESANDO MENSAJE:", error);
        }
      }
    });

  } catch (error) {
    console.error("ERROR DE INICIO:", error);
    starting = false;

    if (!reconnectTimer && !stopped) {
      reconnectTimer = setTimeout(() => {
        reconnectTimer = null;
        startBot();
      }, 5000);
    }
  }
}

process.on("SIGINT", () => {
  stopped = true;

  if (reconnectTimer) {
    clearTimeout(reconnectTimer);
  }

  console.log("\nBot detenido. La sesión guardada se conserva.");
  process.exit(0);
});

startBot();
